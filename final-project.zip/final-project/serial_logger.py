import serial
import csv
import sys
import os
import time
from datetime import datetime

PORT = "COM11"
BAUDRATE = 115200
OUTPUT_DIR = "dados_csv"

MAX_SAMPLES = 15000
MAX_DURATION_S = 5 * 60  # 5 minutos

os.makedirs(OUTPUT_DIR, exist_ok=True)

filename = os.path.join(OUTPUT_DIR, f"vibration_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")

print(f"Conectando em {PORT} @ {BAUDRATE}...")
print(f"Salvando em: {filename}")
print(f"Meta: {MAX_SAMPLES} amostras ou {MAX_DURATION_S // 60} minutos")
print("Pressione Ctrl+C para parar antecipadamente.\n")

header_written = False
sample_count = 0

try:
    with serial.Serial(PORT, BAUDRATE, timeout=2) as ser, \
         open(filename, "w", newline="", encoding="utf-8") as f:

        writer = csv.writer(f)
        start_time = time.time()

        while sample_count < MAX_SAMPLES:
            elapsed = time.time() - start_time
            if elapsed >= MAX_DURATION_S:
                print(f"\nTempo limite atingido ({MAX_DURATION_S // 60} min).")
                break

            line = ser.readline().decode("utf-8", errors="replace").strip()

            if not line:
                continue

            # cabeçalho CSV
            if line.startswith("index,"):
                if not header_written:
                    writer.writerow(line.split(","))
                    f.flush()
                    header_written = True
                continue

            # ignora linhas de log/status
            if "," not in line or line[0].isalpha():
                continue

            # linha de dados: index,timestamp_ms,Ax,Ay,Az,vib,alarme
            parts = line.split(",")
            if len(parts) == 7:
                writer.writerow(parts)
                f.flush()
                sample_count += 1

                if sample_count % 500 == 0:
                    pct = sample_count / MAX_SAMPLES * 100
                    elapsed_str = f"{int(elapsed // 60):02d}:{int(elapsed % 60):02d}"
                    print(f"  [{elapsed_str}] {sample_count}/{MAX_SAMPLES} amostras ({pct:.0f}%)")

        print(f"\nCaptura concluida: {sample_count} amostras em {elapsed:.1f}s")
        print(f"Arquivo salvo: {filename}")

except serial.SerialException as e:
    print(f"Erro serial: {e}")
    sys.exit(1)
except KeyboardInterrupt:
    print(f"\nCaptura interrompida: {sample_count} amostras salvas em {filename}")
