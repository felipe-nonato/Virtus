import serial
import csv
import sys
import os
from datetime import datetime

PORT = "COM3"       # ajuste para a porta do seu STM32
BAUDRATE = 115200
OUTPUT_DIR = "dados_csv"

os.makedirs(OUTPUT_DIR, exist_ok=True)

filename = os.path.join(OUTPUT_DIR, f"vibration_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")

print(f"Conectando em {PORT} @ {BAUDRATE}...")
print(f"Salvando em: {filename}")
print("Pressione Ctrl+C para parar.\n")

header_written = False

try:
    with serial.Serial(PORT, BAUDRATE, timeout=2) as ser, \
         open(filename, "w", newline="", encoding="utf-8") as f:

        writer = csv.writer(f)

        while True:
            line = ser.readline().decode("utf-8", errors="replace").strip()

            if not line:
                continue

            print(line)

            # escreve cabeçalho CSV uma vez
            if line.startswith("index,"):
                if not header_written:
                    writer.writerow(line.split(","))
                    f.flush()
                    header_written = True
                continue

            # ignora linhas de status/log (não são dados CSV)
            if "," not in line or line[0].isalpha():
                continue

            # linha de dados: index,timestamp_ms,Ax,Ay,Az,rms_vib,alarme
            parts = line.split(",")
            if len(parts) == 7:
                writer.writerow(parts)
                f.flush()

except serial.SerialException as e:
    print(f"Erro serial: {e}")
    sys.exit(1)
except KeyboardInterrupt:
    print(f"\nCaptura encerrada. Arquivo salvo: {filename}")
